from setuptools import setup
setup(
    name="calculos",
    version="0.1",
    description="Este es un paquete de ejemplo",
    author="Maricel Monge",
    author_email="marimong25@gmail.com",
    packages=['calculos','calculos.utilidades'],
    scripts=[]
)